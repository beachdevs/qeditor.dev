#!/bin/bash
set -euo pipefail

CONTAINER_NAME="qeditor-host"

container stop "$CONTAINER_NAME" 2>/dev/null || true
container rm "$CONTAINER_NAME" 2>/dev/null || true

echo "Container stopped: $CONTAINER_NAME"
