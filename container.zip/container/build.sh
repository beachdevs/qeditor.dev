#!/bin/bash

# Define image and container names
IMAGE_NAME="qeditor"
CONTAINER_NAME="qeditor"

# 1. Build the image using Apple's container CLI
# Note: container builder can be configured for resources if needed
echo "Building image: $IMAGE_NAME..."
container build --no-cache -t $IMAGE_NAME .

# Stop and remove existing container if it exists
echo "Stopping and removing existing container if it exists..."
container stop $CONTAINER_NAME 2>/dev/null
container rm $CONTAINER_NAME 2>/dev/null

# Run the container with specified resources using Apple's container CLI
# --memory "4G" limits memory to 4GB
# --cpus 4 limits CPU usage to 4 cores
# -p 7681:7681 maps the ttyd port
echo "Running container $CONTAINER_NAME..."
container run -d \
    --name $CONTAINER_NAME \
    -p 7681:7681 \
    --memory "4G" \
    --cpus 4 \
    $IMAGE_NAME

echo "Container is running at http://localhost:7681"